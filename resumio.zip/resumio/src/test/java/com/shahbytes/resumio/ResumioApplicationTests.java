package com.shahbytes.resumio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResumioApplicationTests {

	@Test
	void contextLoads() {
	}

}
